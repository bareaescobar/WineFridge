export const TOPICS = {
  WEB_TO_RPI_COMMAND: 'winefridge/command',
  RPI_TO_WEB_EVENT: 'winefridge/status',
}
