export const TOPICS = {
  WEB_TO_RPI_COMMAND: 'winefridge/system/command',
  RPI_TO_WEB_EVENT: 'winefridge/system/status',
}
